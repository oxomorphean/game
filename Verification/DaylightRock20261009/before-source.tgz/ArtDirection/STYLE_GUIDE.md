# Quy tắc mỹ thuật v4 — chibi góc nhìn cao

Yêu cầu ngày 07/10/2026: dùng [Soul Strike](References/soul-strike-high-view.png) làm tham chiếu góc nhìn, tỷ lệ và cách phân cấp hình ảnh. Đây là mẫu để duyệt; thiết kế nhân vật và môi trường thuộc bối cảnh tu tiên của Linh Thú Ký.

- Góc nhìn từ cao xuống, quy ước khoảng 60–65 độ so với mặt đất trong bản vẽ: thấy đỉnh đầu, đỉnh mai và mặt trên vật thể; thân/chân bị rút ngắn. Camera Unity 2D vẫn nhìn thẳng mặt phẳng sprite, góc cao nằm trong thiết kế ảnh.
- Nhân vật chibi khoảng hai đầu, đầu chiếm gần nửa chiều cao, tóc thành vài khối rõ, thân ngắn và hai chân tách nhau. Ngự thú sư tóc bạc, áo xanh đen–trắng ngà, đai xanh ngọc, điểm vàng ít, kiếm ngắn. Hình phải đọc được khi hiển thị cao khoảng 55–85 px.
- Huyền Giáp Quy giữ mai than đen, ít đường hoa văn vàng, da xanh ngọc; mai thấy từ trên nhiều hơn thành bên. Không phủ nhiều trang sức hoặc chấm da vụn.
- Viền xanh đen gọn, cùng độ dày thị giác; tô 2–3 mảng sáng tối. Mặt trời ẩn di chuyển từ đông (+X của map) sang tây: bóng sáng ngả tây, trưa nằm quanh gốc theo hình tán, chiều ngả đông và dài hơn. Bóng lấy silhouette vật thể, nối chân cây/đá; cây và đá không dùng bóng elip phụ. Không vẽ mặt trời trên màn hình; thanh thời gian hiển thị giờ ban ngày. Hoàng hôn có ánh vàng; tạm chưa làm buổi tối. Nét nhân vật rõ hơn nền. Không pixel, không mô hình bóng nhựa, không lông/tóc tả thực.
- Nền là mảng cỏ xanh rộng yên mắt, chỉ thỉnh thoảng có mảng xanh đậm/nhạt nhẹ; không rắc nét vụn hoặc texture nham nhở. Đá, cây, bụi cỏ tập trung ít cụm; phần giữa để trống cho nhân vật và chiến đấu.
- Gần trưa, bóng đá bám đáy silhouette, không có dải bóng rời dưới đá. Bóng thân cây hòa vào bóng tán, không đậm hơn vì lưới tự chồng lớp; kiểm tra thêm mốc 11:30 khi chỉnh phép chiếu bóng.
- Góc nhìn và tỷ lệ phải đồng nhất giữa người, thú, đá và cây. Map rộng nhìn thoáng; tránh cổng lớn hoặc tán cây chắn cả trung tâm.
- PNG alpha cho người và thú. Ảnh người và quy dùng mipmap/Trilinear khi hiển thị nhỏ trong bản chơi để giảm răng cưa và lốm đốm; sprite môi trường giữ Bilinear hiện có. Texture cỏ/đất lặp của mẫu map chính dùng mipmap/Trilinear. Nền giữ tỷ lệ, không kéo méo nền hoặc nhân vật.
- Animation phải dùng cùng nguồn nhân vật để giữ mặt, kiếm, quần áo và mai ổn định; không sinh ảnh AI độc lập cho từng frame. Theo yêu cầu 08/10, player V1 thử model Blender gắn xương rồi render sprite tám hướng; linh thú và scene mẫu cũ tiếp tục dùng bitmap/SpriteSkin. Nguồn, thông số thử và ảnh mẫu ở [HeroEightDirections](HeroEightDirections/README.md).
- Môi trường chia theo đơn vị bố trí: cây, đá ngoài hồ, bụi cỏ, hoa và bụi cây là PNG alpha/prefab riêng. Theo lựa chọn cách 2 của chủ dự án, mẫu map chính dùng texture cỏ/đất lặp, đường mesh chỉnh bằng điểm uốn và đá lát riêng; giữ mép đất bất quy tắc, rộng hẹp tự nhiên như ảnh tham chiếu. Chỉ thử map chính; các mẫu cũ vẫn giữ nền PNG. Hồ nước gồm nước, đá bờ, cỏ bờ và lá sen trong cùng một PNG/prefab: kéo hồ di chuyển cả cụm. Mỗi đối tượng có Transform riêng; bóng cây là sprite con riêng. Thứ tự vẽ theo vị trí chân; nước, nền đất, đá lát và bóng nằm dưới nhân vật. Va chạm thuộc logic, không suy ra từ ảnh.

## Mẫu hiện hành

`Assets/_Project/Art/CartoonV2/` có ngự thú sư và linh quy góc cao. Thư mục `Environment/` chứa bảy PNG gồm nền cỏ–đường cố định và sáu loại đồ vật riêng (hồ là một cụm). `Assets/_Project/Content/Prefabs/Environment/MeadowMap.prefab` lưu bố cục dùng chung; các prefab đồ vật nằm cạnh nó. Nhập lại ảnh giữ nguyên map đã bố trí. Scene `CartoonArtTrial.unity` dùng hai SpriteSkin sáu bone; người được điều khiển ban đầu, thú đi theo; Tab đổi vai, R về điểm xuất phát. Renderer không sở hữu input hoặc dữ liệu lưu; controller preview không đọc/ghi save.

Mẫu nền chỉnh sửa mới nằm ở `MeadowMainMap.prefab`, dùng trong `CultivationV1.unity`. Nguyên liệu riêng nằm ở `Art/CartoonV2/Terrain/`; hướng dẫn chỉnh đường và bằng chứng nằm ở `ArtDirection/CartoonV2/MainMapMethod2/`. Mẫu này giữ kích thước map, vị trí 21 đồ vật và sáu footprint hiện có; chưa mở rộng map hoặc thêm luật xây dựng.

Scene logic `ThanDinhPrototype.unity` dùng ảnh người cho player/thần hồn và ảnh quy cho thú, với mesh motion Canvas nhẹ. Người chạy nhấc chân luân phiên; idle giữ chân yên. Bóng tiếp xúc của môi trường nằm sát chân asset và dưới nhân vật. Scene combat `PlayerCombatTrial.unity` dùng rig người với pose lấy đà/chém, trúng đòn, gục và trở lại đứng. Luật game, nghề, vật phẩm, dashboard và save schema giữ nguyên. Player của CultivationV1 và PlayerCombatTrial dùng mẫu sprite tám hướng với trước/sau riêng; CartoonArtTrial và prototype cũ giữ hình trái/phải để khôi phục và so sánh.

## Duyệt mẫu và khôi phục

Đối chiếu góc nhìn, đầu/thân, viền và cỏ ở đúng kích thước chơi; xem idle/walk và đổi người/thú không mất chủ thể; compile và build phải thành công. Không kết luận FPS hay sức chứa online chỉ từ mẫu ảnh.

Bản trước khi tách môi trường nằm ở `Verification/CartoonTrial/before-modular-props.tgz`; ảnh nền ghép cũ `field.png` được giữ làm tham chiếu và không còn dùng để dựng map. Art CartoonV1 được giữ nguyên để so sánh/quay lại. Source và hai scene trước chỉnh góc nhìn nằm ở `Verification/CartoonTrial/cartoon-v1-code-before-high-view.tgz`. Pixel/Aseprite cũ vẫn đã gỡ; bản nén pixel trước đó không phải asset đang dùng.

## UI V1 — yêu cầu chủ dự án 07/10/2026

Giao diện game cần hiện đại, gọn gàng và thanh lịch. Dùng phân cấp chữ, khoảng cách và màu nhấn tiết chế; giảm khung trang trí, viền vàng và những bảng đặc che sân chơi. HUD ưu tiên HP/linh lực, kỹ năng/cooldown và mục tiêu ngắn; chỉ số chi tiết nằm trong bảng chức năng. Bảng hành trang/công pháp cần dễ đọc, đủ dấu tiếng Việt, có lý do khi lệnh bị từ chối. Dashboard phát triển dành cho chủ dự án vẫn tách khỏi UI chơi. Hướng UI này không thay đồ họa chibi, sprite và map hiện hành.
