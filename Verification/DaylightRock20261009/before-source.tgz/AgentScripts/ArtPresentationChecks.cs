using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using LinhThu.Prototype;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Checks grounded prop presentation and human poses without changing a scene or gameplay state.</summary>
public static class ArtPresentationChecks
{
    private const string ReportRoot = "Verification/ArtMotionGrounding/";
    [Serializable] private sealed class Check { public string name; public bool passed; public string evidence; }
    [Serializable] private sealed class Report { public int passed, failed; public Check[] checks; }

    public static string Before() => Run("before-checks.json");
    public static string After() => Run("checks.json");

    private static string Run(string filename)
    {
        if (!EditorApplication.isPlaying) throw new InvalidOperationException("Run sprite-mesh checks in Play Mode.");
        var checks = new List<Check>();
        Action<string, bool, string> check = (name, passed, evidence) => checks.Add(new Check { name = name, passed = passed, evidence = evidence });
        var map = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Project/Content/Prefabs/Environment/MeadowMap.prefab").GetComponent<ModularMapLayout>();
        var props = map.GetComponentsInChildren<ModularMapProp>();
        var standing = props.Where(p => !p.floorLayer).ToArray();
        var contactProps = standing.Where(p => p.visual.sprite.name != "cherry-tree" && p.visual.sprite.name != "rock").ToArray();
        check("Trees and rocks have silhouette shadows without an ellipse", standing.Where(p => p.visual.sprite.name == "cherry-tree" || p.visual.sprite.name == "rock").All(p =>
            p.contactShadow == null && p.transform.Find("Bóng tiếp xúc") == null && p.castShadow.sprite.texture == p.visual.sprite.texture), "Two trees and three rocks use only their own silhouette");
        check("Tree cast shadow overlaps its roots", props.Where(p => p.visual.sprite.name == "cherry-tree").All(p =>
            p.castShadow != null && p.castShadow.transform.localPosition.y >= -.05f && p.castShadow.transform.localPosition.x <= .30f),
            string.Join("; ", props.Where(p => p.visual.sprite.name == "cherry-tree").Select(p => p.name + ": " + p.castShadow.transform.localPosition)));
        check("Other contact shades remain below actors and follow prop roots", contactProps.All(p =>
        {
            var foot = p.transform.Find("Bóng tiếp xúc");
            var renderer = foot == null ? null : foot.GetComponent<SpriteRenderer>();
            return renderer != null && renderer.sprite != null && renderer.sortingOrder < 0 && renderer.bounds.Contains(p.transform.position);
        }), "Ground contact point must be inside shade bounds");
        var canvas = new GameObject("Temporary presentation check", typeof(RectTransform));
        try
        {
            var art = new PrototypeMapArt { smoothStyle = true, environmentPrefab = map };
            art.BuildGarden((RectTransform)canvas.transform);
            var contact = canvas.GetComponentsInChildren<Image>().Where(i => i.name == "Bóng tiếp xúc").ToArray();
            check("Canvas map excludes tree/rock ellipses and keeps other contact shades below props", contact.Length == props.Length - 5 && contact.All(i =>
                i.transform.parent == canvas.transform && i.transform.GetSiblingIndex() < art.Foreground.Min(p => p.GetSiblingIndex())),
                contact.Length + " Canvas contact shades");
            check("Shared map retains its independent prop roots", props.Length == 21 && art.Foreground.Count == 20 && map.ground.sprite.name == "ground-road", props.Length + " roots");
            bool unfolded = true, rockOnGround = true, trunkUnderCanopy = true;
            var propShadows = canvas.GetComponentsInChildren<DaylightCanvasEffect>().Where(e => e.shadow && e.footprint.w >= 2).ToArray();
            float lightingHour = DaylightPresentation.Current.Hour;
            try
            {
                foreach (float hour in new[] { 8f, 11.5f, 12f, 16f })
                {
                    DaylightPresentation.ApplyLighting(hour);
                    foreach (var effect in propShadows)
                    using (var mesh = new VertexHelper())
                    {
                        effect.ModifyMesh(mesh);
                        var bottom = new UIVertex(); var top = new UIVertex();
                        mesh.PopulateUIVertex(ref bottom, 0); mesh.PopulateUIVertex(ref top, 120);
                        float previousY = bottom.position.y;
                        for (int row = 1; row <= 24; row++)
                        {
                            var point = new UIVertex(); mesh.PopulateUIVertex(ref point, row * 5);
                            unfolded &= point.position.y > previousY; previousY = point.position.y;
                        }
                        if (effect.footprint.w == 3)
                        {
                            var image = effect.GetComponent<Image>();
                            float foot = image.sprite.pivot.y / image.sprite.rect.height;
                            rockOnGround &= Mathf.Abs(Mathf.Lerp(bottom.position.y, top.position.y, foot)) < .001f;
                        }
                        if (effect.footprint.w == 2 && hour == 11.5f)
                            trunkUnderCanopy &= bottom.color.a < top.color.a * .15f;
                    }
                }
            }
            finally { DaylightPresentation.ApplyLighting(lightingHour); }
            check("Tree and rock projections do not fold or shade themselves twice", propShadows.Length == 5 && unfolded, "Ascending shadow rows at 08:00, 11:30, 12:00 and 16:00");
            check("Rock silhouette stays anchored at the actual base", rockOnGround, "The imported visible-bottom pivot projects onto the same ground point");
            check("Near-noon canopy covers the trunk shadow", trunkUnderCanopy, "Trunk opacity below 15 percent of canopy opacity at 11:30");
            var actor = new GameObject("Temporary Canvas actor", typeof(RectTransform), typeof(Image));
            actor.transform.SetParent(canvas.transform, false);
            var actorImage = actor.GetComponent<Image>();
            actorImage.sprite = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/_Project/Art/CartoonV2/hero.png");
            actorImage.rectTransform.sizeDelta = new Vector2(75, 100);
            var uiRig = actor.AddComponent<CartoonUiRig>(); uiRig.Human = true;
            var uiFlags = BindingFlags.Instance | BindingFlags.NonPublic;
            var uiBlend = typeof(CartoonUiRig).GetField("motionBlend", uiFlags);
            var uiPhase = typeof(CartoonUiRig).GetField("stridePhase", uiFlags);
            Func<float, float, Vector3[]> feet = (blend, phase) =>
            {
                uiBlend.SetValue(uiRig, blend); uiPhase.SetValue(uiRig, phase);
                using (var mesh = new VertexHelper())
                {
                    uiRig.ModifyMesh(mesh);
                    var left = new UIVertex(); var right = new UIVertex();
                    mesh.PopulateUIVertex(ref left, 19 + 8); mesh.PopulateUIVertex(ref right, 19 + 10);
                    return new[] { left.position, right.position };
                }
            };
            var idle = feet(0, 0); var idleLater = feet(0, Mathf.PI * 1.5f);
            check("Canvas idle keeps both feet at rest", idle.SequenceEqual(idleLater), "No foot offset when motion blend is zero");
            var leftStep = feet(1, Mathf.PI * .5f); var rightStep = feet(1, Mathf.PI * 1.5f);
            check("Canvas walking lifts one foot at a time", leftStep[0].y > idle[0].y && Mathf.Abs(leftStep[1].y - idle[1].y) < .001f &&
                rightStep[1].y > idle[1].y && Mathf.Abs(rightStep[0].y - idle[0].y) < .001f,
                "Left and right half cycles alternate their raised foot");
        }
        finally { UnityEngine.Object.DestroyImmediate(canvas); }

        var daylight = DaylightPresentation.Current;
        float savedHour = daylight.Hour; bool savedAdvance = daylight.advanceTime;
        try
        {
            DaylightPresentation.ApplyLighting(8);
            float morningLength = DaylightPresentation.ShadowLength;
            check("Morning shadows point west from the eastern sun", DaylightPresentation.ShadowDirection.x < 0 && morningLength > .5f, DaylightPresentation.ShadowDirection.ToString());
            DaylightPresentation.ApplyLighting(12);
            check("Noon shadows stay under the canopy", DaylightPresentation.ShadowLength < .001f && DaylightPresentation.Overhead > .99f, "No horizontal throw; full overhead footprint");
            DaylightPresentation.ApplyLighting(16);
            check("Afternoon shadows point east and sunlight becomes warm", DaylightPresentation.ShadowDirection.x > 0 && Mathf.Abs(DaylightPresentation.ShadowLength - morningLength) < .001f && DaylightPresentation.LightTint.g < .99f, DaylightPresentation.ShadowDirection.ToString());
            daylight.SetHour(17); daylight.advanceTime = true;
            var daylightFlags = BindingFlags.Instance | BindingFlags.NonPublic;
            typeof(DaylightPresentation).GetField("started", daylightFlags).SetValue(daylight, Time.unscaledTime - daylight.dayDurationSeconds);
            typeof(DaylightPresentation).GetMethod("LateUpdate", daylightFlags).Invoke(daylight, null);
            check("Daylight repeats instead of staying at sunset", Mathf.Abs(daylight.Hour - 17) < .01f, "Hour after one complete cycle: " + daylight.Hour);
            check("Time display is readable and does not intercept input", daylight.GetComponentsInChildren<TMPro.TextMeshProUGUI>().Any(t => t.text.Contains("Ban ngày") && !t.raycastTarget && t.font != null), "Existing Vietnamese font and no raycast target");
            var liveProps = UnityEngine.Object.FindObjectsByType<ModularMapProp>().Where(p => !p.floorLayer && p.castShadow != null).ToArray();
            check("Live shadow meshes retain their source silhouettes", liveProps.Length > 0 && liveProps.All(p =>
            {
                var render = p.castShadow.GetComponentInChildren<MeshRenderer>(); var filter = p.castShadow.GetComponentInChildren<MeshFilter>();
                var block = new MaterialPropertyBlock(); if (render != null) render.GetPropertyBlock(block);
                return render != null && filter != null && filter.sharedMesh.vertexCount > 4 && block.GetTexture("_MainTex") == p.visual.sprite.texture;
            }), liveProps.Length + " grounded shadow meshes");
        }
        finally { daylight.advanceTime = savedAdvance; daylight.SetHour(savedHour); }

        var rig = UnityEngine.Object.FindObjectsByType<CartoonCharacterRig>().First(r => r.kind == CartoonBodyKind.Human && r.Skin != null);
        var root = rig.gameObject; var shadow = rig.contactShadow;
        var position = root.transform.position; var rotation = root.transform.rotation; var scale = root.transform.localScale;
        var flags = BindingFlags.Instance | BindingFlags.NonPublic;
        var fields = typeof(CartoonCharacterRig).GetFields(flags).Where(f => f.FieldType == typeof(float) || f.FieldType == typeof(bool)).ToArray();
        var saved = fields.Select(f => f.GetValue(rig)).ToArray();
        try
        {
            var bones = rig.Skin.boneTransforms;
            check("Human skin keeps six bones and source identity", rig.BoneCount == 6 && rig.Skin.GetComponent<SpriteRenderer>().sprite.texture == rig.source.texture, rig.source.name);
            check("Human sprite has the deformable runtime grid", rig.Skin.GetComponent<SpriteRenderer>().sprite.vertices.Length == 475, "475 vertices");
            var live = UnityEngine.Object.FindObjectsByType<CartoonCharacterRig>().Where(r => r != rig && r.Skin != null).ToArray();
            check("Live scene skins have current deformed vertices", live.Length >= 1 && live.All(r => r.Skin.HasCurrentDeformedVertices()), live.Length + " other live actors");
            var rest = (Vector3[])typeof(CartoonCharacterRig).GetField("rest", flags).GetValue(rig);
            var restLeft = rest[2]; var restRight = rest[3];
            var tick = typeof(CartoonCharacterRig).GetMethod("LateUpdate", flags);
            var time = typeof(CartoonCharacterRig).GetField("<VisualTime>k__BackingField", flags);
            rig.SetMotion(Vector2.zero); rig.SetCombatPose(Vector2.right, 0, false, false, false);
            for (int i = 0; i < 60; i++) tick.Invoke(rig, null);
            time.SetValue(rig, .42f); tick.Invoke(rig, null);
            check("Idle feet stay planted without walking in place", Mathf.Abs(Mathf.DeltaAngle(bones[2].localEulerAngles.z, 0)) < .001f &&
                Mathf.Abs(Mathf.DeltaAngle(bones[3].localEulerAngles.z, 0)) < .001f && bones[2].localPosition == restLeft && bones[3].localPosition == restRight,
                "Idle foot angles: " + bones[2].localEulerAngles.z + ", " + bones[3].localEulerAngles.z);
            rig.SetMotion(Vector2.right);
            bool leftLift = false, rightLift = false, alternate = true;
            for (int i = 0; i < 120; i++)
            {
                time.SetValue(rig, i * .035f); tick.Invoke(rig, null);
                float left = bones[2].localPosition.y - restLeft.y, right = bones[3].localPosition.y - restRight.y;
                leftLift |= left > .015f; rightLift |= right > .015f;
                alternate &= !(left > .015f && right > .015f);
            }
            check("Walking alternates lifted feet", leftLift && rightLift && alternate, "Left: " + leftLift + "; right: " + rightLift + "; alternate: " + alternate);
            check("Animation leaves the gameplay root at ground contact", root.transform.position == position && root.transform.rotation == rotation && root.transform.localScale == scale,
                root.transform.position.ToString());
            check("Actor shadow stays on ground below foreground", shadow.sortingOrder < 0, "Order: " + shadow.sortingOrder);
            rig.SetCombatPose(Vector2.right, -.4f, false, false, false); tick.Invoke(rig, null);
            float windup = Mathf.DeltaAngle(0, bones[4].localEulerAngles.z);
            rig.SetCombatPose(Vector2.right, 1, false, false, false); tick.Invoke(rig, null);
            float strike = Mathf.DeltaAngle(0, bones[4].localEulerAngles.z);
            check("Windup and strike use opposite sword-arm poses", windup > 10 && strike < -35, "Windup: " + windup + "; strike: " + strike);
            rig.SetCombatPose(Vector2.right, 0, true, false, false); tick.Invoke(rig, null);
            check("Collapse pose is distinct and reversible", Mathf.Abs(Mathf.DeltaAngle(0, bones[0].localEulerAngles.z)) >= 50 && rig.CombatDown,
                "Body angle: " + bones[0].localEulerAngles.z);
            rig.SetMotion(Vector2.zero); rig.SetCombatPose(Vector2.right, 0, false, false, false);
            for (int i = 0; i < 60; i++) tick.Invoke(rig, null);
            check("Respawn returns to an upright human", !rig.CombatDown && Mathf.Abs(Mathf.DeltaAngle(0, bones[0].localEulerAngles.z)) < 5 &&
                rig.Skin.GetComponent<SpriteRenderer>().color == Color.white, "Neutral body and tint");
        }
        finally
        {
            for (int i = 0; i < fields.Length; i++) fields[i].SetValue(rig, saved[i]);
            typeof(CartoonCharacterRig).GetMethod("LateUpdate", flags).Invoke(rig, null);
        }
        var report = new Report { passed = checks.Count(c => c.passed), failed = checks.Count(c => !c.passed), checks = checks.ToArray() };
        string json = Newtonsoft.Json.JsonConvert.SerializeObject(report, Newtonsoft.Json.Formatting.Indented);
        Directory.CreateDirectory(ReportRoot); File.WriteAllText(ReportRoot + filename, json + "\n");
        return json;
    }
}
