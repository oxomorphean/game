# Quy tắc mỹ thuật v3 — thử nghiệm 2D cartoon nét mượt

Yêu cầu mới ngày 06/10/2026 thay hướng pixel bằng 2D cartoon/chibi nét mượt. Ảnh tham chiếu: [cartoon-reference-03.png](References/cartoon-reference-03.png). Đây là mẫu thử cần chủ dự án duyệt, chưa phải bộ asset sản xuất cuối.

- Viền xanh đen gọn, cùng độ dày thị giác; không lưới pixel hoặc Point filtering.
- Nhân vật chibi, silhouette đọc được ở chiều rộng 80–110 px khi chơi. Huyền Giáp Quy giữ mai đen và một số đường vàng kim rõ, đầu/chân xanh ngọc; không phủ dày trang sức.
- Tô 2–3 mảng sáng tối; một hướng sáng trên trái. Nền ít tương phản hơn nhân vật, màu đất ấm và cỏ xanh; chi tiết tập trung ở vật thể ven đường.
- Cỏ tạo mảng rộng xanh mướt, ít mảng tối nhẹ, không rắc nét cỏ vụn khắp sân. Cây có tán theo cụm bồng bềnh; bóng đổ tiết chế.
- Góc nhìn cao, thấy mặt trên/mặt trước, giữ đồng nhất giữa nhân vật và môi trường. Nhân vật chưa có hướng lên/xuống riêng thì phải ghi rõ.
- PNG alpha cho thú; Bilinear, không mipmap ở camera thử cố định; chọn độ phân giải theo kích thước chơi. Không áp chuẩn PPU16/palette pixel cũ lên mẫu mới.
- Animation giữ nguyên bitmap thiết kế và dùng khung xương/lưới, không sinh một ảnh AI độc lập cho mỗi frame. Kiểm tra trọng tâm, chân, mai và màu ở kích thước chơi.
- Tách lớp vật thể và tile khi sản xuất map chính. Nền sân mẫu hiện là một ảnh phẳng để duyệt hướng, không phải hệ thống ráp map hoàn chỉnh.

## Mẫu hiện tại

`Assets/_Project/Art/CartoonV1/`: hai ảnh gốc ImageGen và icon tạm tạo bằng Unity API. Scene `CartoonArtTrial.unity` dùng SpriteSkin của gói chính thức Unity 2D Animation 16.0.1, 6 bone, có di chuyển WASD/bấm sân. Scene logic dùng cùng hai ảnh và mesh motion nhẹ trên Canvas; không sửa luật game hoặc save.

Asset pixel cũ đã gỡ khỏi Assets và thư mục sản xuất. Một bản nén nhỏ để quay lại nằm ở `Verification/CartoonTrial/pixel-assets-before.tgz`; không tạo thêm bản sao dự án đầy đủ.

## Duyệt mẫu

Kiểm tra nét viền, màu, tỷ lệ và sự rõ ràng ở kích thước chơi; quan sát idle/walk không trôi hình; bản web phải tải và di chuyển được. Không kết luận phong cách này nhẹ hay nặng hơn trước khi có phép đo cùng máy, cùng cảnh và cùng mật độ.
