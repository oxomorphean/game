# Linh Thú Ký

Đang thử mỹ thuật **2D cartoon/chibi nét mượt** theo yêu cầu ngày 06/10/2026. [Mẫu rùa có animation](http://127.0.0.1:8788/) · [Chơi logic](http://127.0.0.1:8789/#choi).

Scene mẫu: `Assets/_Project/Content/Scenes/CartoonArtTrial.unity`. WASD/phím mũi tên hoặc bấm sân để đi; R về điểm xuất phát. Rùa dùng SpriteSkin thật của gói **Unity 2D Animation 16.0.1**, với 6 bone. Môi trường là một ảnh phẳng để thử phong cách; thú mới có trái/phải, chưa có bộ hình riêng cho mọi hướng.

Asset mới nằm trong `Assets/_Project/Art/CartoonV1/`. Hai ảnh chính được tạo bằng ImageGen; icon tài nguyên hiện là hình tạm. [Quy tắc mỹ thuật](ArtDirection/STYLE_GUIDE.md) sở hữu hướng hiện hành. Mẫu web ở `WebBuild/`; chạy `python3 serve.py` để mở cổng 8788.

Scene logic giữ tại `Assets/_Project/Content/Scenes/ThanDinhPrototype.unity`; phần nhìn thay bằng nền/rùa mới và mesh motion nhẹ trong Canvas. Luật, nghề, vật phẩm, dashboard chủ dự án và dữ liệu lưu được giữ nguyên. [Logic 03](Architecture/LOGIC_V3.md) · [Kiến trúc code](Architecture/CODE_ARCHITECTURE.md) · [Thiết kế online](Architecture/ONLINE_ARCHITECTURE.md). Hiện chưa có multiplayer/server hoặc bằng chứng sức chứa 100–300 người.

Bộ pixel và Aseprite/MCP cũ đã gỡ theo yêu cầu. Một bản nén để quay lại nằm ở `Verification/CartoonTrial/pixel-assets-before.tgz` (asset và các file trình bày trước thay đổi, không phải bản sao toàn dự án). Gói Unity lấy từ registry `https://packages.unity.com`; thông tin cài và kiểm chứng nằm ở `Verification/CartoonTrial/`.

Dùng Unity Pipeline/CLI và Editor API để import/save scene; không sửa YAML scene/prefab bằng tay. Builder mẫu là `Assets/_Project/Editor/CartoonArtBuilder.cs`, builder logic là `AgentScripts/LogicBuilder.cs`.
