using System;
using Unity.Collections;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.U2D;
using UnityEngine.U2D.Animation;

namespace LinhThu.Prototype
{
    /// <summary>Six-bone art trial using Unity SpriteSkin; this controller owns no gameplay or save state.</summary>
    public sealed class CartoonPetRig : MonoBehaviour
    {
        public Sprite source;
        public float speed = 2.3f;
        public Vector2 virtualMove;
        public float VisualTime { get; private set; }
        public bool Moving { get; private set; }
        public int BoneCount => bones == null ? 0 : bones.Length;
        private Transform[] bones;
        private Vector3[] rest;
        private Sprite runtimeSprite;
        private InputAction move;
        private Vector3 target;
        private bool hasTarget;
        private float heading = 1;
        private Vector3 spawn;
        private GameObject visual;
        private SpriteSkin skin;
        public SpriteSkin Skin => skin;

        private void Start()
        {
            if (source == null) throw new InvalidOperationException("Cartoon trial needs a turtle sprite.");
            spawn = transform.position;
            visual = new GameObject("Huyen Giap Quy — six bone SpriteSkin"); visual.layer = gameObject.layer;
            visual.transform.SetParent(transform, false);
            var renderer = visual.AddComponent<SpriteRenderer>(); renderer.sortingOrder = 10;
            runtimeSprite = Sprite.Create(source.texture, source.rect, new Vector2(.5f, .19f), 256, 0, SpriteMeshType.FullRect);
            runtimeSprite.name = "Huyen Giap Quy rigged runtime";
            var size = runtimeSprite.bounds.size;
            visual.transform.localScale = Vector3.one * (2.15f / size.x);
            const int cols=24, rows=18;
            var vertices = new Vector2[(cols+1)*(rows+1)]; var triangles = new ushort[cols*rows*6];
            var weights = new NativeArray<BoneWeight>(vertices.Length, Allocator.Temp);
            for(int y=0;y<=rows;y++) for(int x=0;x<=cols;x++)
            {
                int i=y*(cols+1)+x; float u=(float)x/cols,v=(float)y/rows;
                vertices[i] = new Vector2(u*runtimeSprite.rect.width,v*runtimeSprite.rect.height);
                int bone=0; float strength=0;
                if(u>.65f && v>.32f){bone=1;strength=Mathf.SmoothStep(0,1,(u-.65f)/.1f);}
                else if(v<.37f && u>.48f && u<.68f){bone=2;strength=Mathf.Clamp01((.40f-v)/.16f);}
                else if(v<.35f && u<.4f){bone=3;strength=Mathf.Clamp01((.38f-v)/.15f);}
                else if(v<.34f && u>=.68f){bone=4;strength=Mathf.Clamp01((.37f-v)/.14f);}
                else if(u<.23f && v>.30f && v<.52f){bone=5;strength=Mathf.Clamp01((.26f-u)/.09f);}
                weights[i]=new BoneWeight{boneIndex0=bone,weight0=strength,boneIndex1=0,weight1=1-strength};
            }
            int t=0;
            for(int y=0;y<rows;y++) for(int x=0;x<cols;x++)
            {
                ushort a=(ushort)(y*(cols+1)+x),b=(ushort)(a+1),c=(ushort)(a+cols+1),d=(ushort)(c+1);
                triangles[t++]=a;triangles[t++]=c;triangles[t++]=b;triangles[t++]=b;triangles[t++]=c;triangles[t++]=d;
            }
            runtimeSprite.OverrideGeometry(vertices,triangles);
            string[] names={"Body","Head","Front near","Rear near","Front far","Tail"};
            var anchors=new[]{new Vector2(.5f,.5f),new Vector2(.70f,.46f),new Vector2(.59f,.29f),new Vector2(.28f,.28f),new Vector2(.73f,.29f),new Vector2(.22f,.39f)};
            bones=new Transform[6];rest=new Vector3[6];var definitions=new SpriteBone[6];
            var poses=new NativeArray<Matrix4x4>(6,Allocator.Temp);
            try
            {
                for(int i=0;i<6;i++)
                {
                    var go=new GameObject(names[i]);go.transform.SetParent(i==0?visual.transform:bones[0],false);
                    var point=new Vector3((anchors[i].x-.5f)*size.x,(anchors[i].y-.19f)*size.y,0);
                    go.transform.localPosition=i==0?point:point-bones[0].localPosition;
                    bones[i]=go.transform;rest[i]=go.transform.localPosition;
                    definitions[i]=new SpriteBone{name=names[i],position=rest[i],rotation=Quaternion.identity,length=.2f,parentId=i==0?-1:0};
                    poses[i]=bones[i].worldToLocalMatrix*visual.transform.localToWorldMatrix;
                }
                runtimeSprite.SetBones(definitions);runtimeSprite.SetBindPoses(poses);
            }
            finally { poses.Dispose(); }
            runtimeSprite.SetVertexAttribute(VertexAttribute.BlendWeight,weights); weights.Dispose();
            renderer.sprite=runtimeSprite;
            skin=visual.AddComponent<SpriteSkin>();skin.autoRebind=false;skin.SetRootBone(bones[0]);skin.SetBoneTransforms(bones);
            skin.alwaysUpdate=false;
            move=new InputAction("Art trial movement",InputActionType.Value);
            move.AddCompositeBinding("2DVector").With("Up","<Keyboard>/w").With("Down","<Keyboard>/s").With("Left","<Keyboard>/a").With("Right","<Keyboard>/d");
            move.AddCompositeBinding("2DVector").With("Up","<Keyboard>/upArrow").With("Down","<Keyboard>/downArrow").With("Left","<Keyboard>/leftArrow").With("Right","<Keyboard>/rightArrow");move.Enable();
            Application.runInBackground=true;Application.targetFrameRate=60;
        }
        private void Update()
        {
            if(bones==null)return; VisualTime+=Time.deltaTime;
            var axis=Vector2.ClampMagnitude(move.ReadValue<Vector2>()+virtualMove,1);
            if(Keyboard.current!=null && Keyboard.current.rKey.wasPressedThisFrame)ResetPet();
            if(Mouse.current!=null && Mouse.current.leftButton.wasPressedThisFrame)
            {
                target=Camera.main.ScreenToWorldPoint(new Vector3(Mouse.current.position.ReadValue().x,Mouse.current.position.ReadValue().y,10));
                target.z=0;hasTarget=true;
            }
            if(axis.sqrMagnitude>.01f)hasTarget=false;
            else if(hasTarget){var delta=target-transform.position;if(delta.sqrMagnitude<.03f)hasTarget=false;else axis=((Vector2)delta).normalized;}
            Moving=axis.sqrMagnitude>.01f;
            var pos=transform.position+(Vector3)axis*speed*Mathf.Min(Time.deltaTime,.05f);
            pos.x=Mathf.Clamp(pos.x,-5.9f,5.9f);pos.y=Mathf.Clamp(pos.y,-4.1f,.4f);transform.position=pos;
            if(Mathf.Abs(axis.x)>.01f)heading=Mathf.Sign(axis.x);
            var scale=visual.transform.localScale;scale.x=Mathf.Abs(scale.x)*heading;visual.transform.localScale=scale;
            float phase=VisualTime*(Moving?11:3),a=Moving?1:.14f;
            for(int i=0;i<6;i++){bones[i].localPosition=rest[i];bones[i].localRotation=Quaternion.identity;}
            bones[0].localPosition+=Vector3.up*Mathf.Sin(phase*2)*.018f*a;
            bones[1].localRotation=Quaternion.Euler(0,0,Mathf.Sin(phase)*2.2f*a);
            bones[2].localRotation=Quaternion.Euler(0,0,Mathf.Sin(phase)*10*a);
            bones[3].localRotation=Quaternion.Euler(0,0,-Mathf.Sin(phase)*9*a);
            bones[4].localRotation=Quaternion.Euler(0,0,-Mathf.Sin(phase)*8*a);
            bones[5].localRotation=Quaternion.Euler(0,0,Mathf.Sin(phase)*5*a);
        }
        public void ResetPet(){transform.position=spawn;virtualMove=Vector2.zero;hasTarget=false;}
        private void OnDestroy(){move?.Dispose();if(runtimeSprite!=null)Destroy(runtimeSprite);}
    }
}
