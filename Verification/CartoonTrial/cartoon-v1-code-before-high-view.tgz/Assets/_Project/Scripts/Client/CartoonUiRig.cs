using UnityEngine;
using UnityEngine.UI;
namespace LinhThu.Prototype
{
    /// <summary>Lightweight mesh motion for the Canvas prototype; full SpriteSkin is exercised in the art trial scene.</summary>
    public sealed class CartoonUiRig : BaseMeshEffect
    {
        public bool Moving;
        private void Update(){if(graphic!=null && isActiveAndEnabled)graphic.SetVerticesDirty();}
        public override void ModifyMesh(VertexHelper mesh)
        {
            if(!IsActive())return;
            var image=graphic as Image;if(image==null || image.sprite==null)return;
            var r=graphic.rectTransform.rect;var uv=UnityEngine.Sprites.DataUtility.GetOuterUV(image.sprite);mesh.Clear();
            const int cols=18,rows=12;float a=Moving?1:.1f,phase=Time.unscaledTime*(Moving?11:3);
            for(int y=0;y<=rows;y++)for(int x=0;x<=cols;x++)
            {
                float u=(float)x/cols,v=(float)y/rows,dx=0,dy=0;
                if(v<.38f){float w=Mathf.Clamp01((.40f-v)/.19f);float direction=u<.4f?-1:1;dx=Mathf.Sin(phase)*.011f*a*w*direction;dy=Mathf.Abs(Mathf.Sin(phase))*.012f*a*w;}
                else if(u>.66f)dy=Mathf.Sin(phase)*.0035f*a;
                mesh.AddVert(new Vector3(r.xMin+(u+dx)*r.width,r.yMin+(v+dy)*r.height,0),graphic.color,new Vector2(Mathf.Lerp(uv.x,uv.z,u),Mathf.Lerp(uv.y,uv.w,v)));
            }
            for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){int n=y*(cols+1)+x;mesh.AddTriangle(n,n+cols+1,n+1);mesh.AddTriangle(n+1,n+cols+1,n+cols+2);}
        }
    }
}
