using System;
using System.IO;
using System.Linq;
using LinhThu.Prototype;
using TMPro;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

namespace LinhThu.Editor
{
    /// <summary>Imports the art trial and saves scenes through Editor APIs; never changes gameplay or saves.</summary>
    public static class CartoonArtBuilder
    {
        private const string Root="Assets/_Project/Art/CartoonV1/";
        private const string Scene="Assets/_Project/Content/Scenes/CartoonArtTrial.unity";
        private const string LogicScene="Assets/_Project/Content/Scenes/ThanDinhPrototype.unity";
        public static string Prepare()
        {
            if(EditorApplication.isPlaying)throw new InvalidOperationException("Stop Play before preparing art.");
            foreach(string kind in new[]{"flat","blank","shadow","herb","ore","egg","portal","camp"})CreateIcon(kind);
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            foreach(string path in Directory.GetFiles(Root,"*.png"))
            {
                var i=(TextureImporter)AssetImporter.GetAtPath(path);i.textureType=TextureImporterType.Sprite;i.spriteImportMode=SpriteImportMode.Single;
                i.filterMode=FilterMode.Bilinear;i.mipmapEnabled=false;i.alphaIsTransparency=true;
                i.textureCompression=TextureImporterCompression.Uncompressed;i.spritePixelsPerUnit=100;i.npotScale=TextureImporterNPOTScale.None;
                i.maxTextureSize=path.EndsWith("garden.png",StringComparison.Ordinal)?2048:1024;
                i.spritePivot=new Vector2(.5f,path.EndsWith("huyen-quy.png",StringComparison.Ordinal)?.19f:.5f);
                var ts=new TextureImporterSettings();i.ReadTextureSettings(ts);ts.spriteMeshType=SpriteMeshType.FullRect;ts.spriteAlignment=(int)SpriteAlignment.Custom;i.SetTextureSettings(ts);
                i.SaveAndReimport();
            }
            EditorSceneManager.OpenScene(LogicScene,OpenSceneMode.Single);
            var hud=UnityEngine.Object.FindAnyObjectByType<GameplayHud>();ConfigureArt(hud);
            EditorSceneManager.MarkSceneDirty(hud.gameObject.scene);EditorSceneManager.SaveScene(hud.gameObject.scene);
            AssetDatabase.DeleteAsset("Assets/ArtSample");AssetDatabase.DeleteAsset("Assets/_Project/Art/GardenV8");
            AssetDatabase.SaveAssets();CreateTrial();
            return "Imported smooth cartoon art, replaced logic presentation and removed active pixel assets.";
        }
        public static void ConfigureArt(GameplayHud hud)
        {
            if(hud==null)throw new InvalidOperationException("Missing gameplay HUD.");
            var s=new SerializedObject(hud);s.FindProperty("art.smoothStyle").boolValue=true;
            foreach(var pair in new[]{new[]{"background","garden"},new[]{"animal","huyen-quy"},new[]{"grass","flat"},new[]{"grassShade","flat"},new[]{"gate","portal"},new[]{"tree","blank"},new[]{"puffyTree","blank"},new[]{"rock","ore"},new[]{"pond","blank"},new[]{"flower","herb"},new[]{"lantern","camp"},new[]{"shadow","shadow"},new[]{"bamboo","herb"},new[]{"herb","herb"},new[]{"ore","ore"},new[]{"egg","egg"},new[]{"petal","blank"}})
                s.FindProperty("art."+pair[0]).objectReferenceValue=Load(pair[1]);
            foreach(string name in new[]{"paving","meadow","idle","walk","playerFrames","rippleFrames"})
            {
                var a=s.FindProperty("art."+name);a.arraySize=name=="playerFrames"?1:0;
                if(a.arraySize==1)a.GetArrayElementAtIndex(0).objectReferenceValue=Load("huyen-quy");
            }
            s.ApplyModifiedPropertiesWithoutUndo();
        }
        private static Sprite Load(string name)
        {
            var sprite=AssetDatabase.LoadAssetAtPath<Sprite>(Root+name+".png");
            if(sprite==null)throw new InvalidOperationException("Missing imported cartoon sprite "+name);return sprite;
        }
        private static void CreateIcon(string kind)
        {
            int size=kind=="flat" || kind=="blank"?16:64;
            var tex=new Texture2D(size,size,TextureFormat.RGBA32,false);
            for(int y=0;y<size;y++)for(int x=0;x<size;x++)
            {
                float u=(x+.5f)/size*2-1,v=(y+.5f)/size*2-1,d=0;Color c=Color.clear;
                switch(kind)
                {
                    case "flat":c=new Color(.87f,.83f,.70f);break;
                    case "blank":break;
                    case "shadow":d=u*u+v*v*2;c=new Color(.16f,.2f,.24f,Mathf.Clamp01((1-d)*3));break;
                    case "herb":d=u*u*2+v*v;c=new Color(.26f,.59f,.33f,Mathf.Clamp01((.72f-d)*16));break;
                    case "ore":d=Mathf.Abs(u)*.7f+Mathf.Abs(v);c=new Color(.39f,.52f,.62f,Mathf.Clamp01((.83f-d)*18));break;
                    case "egg":d=u*u*1.8f+v*v;c=new Color(.96f,.83f,.55f,Mathf.Clamp01((.7f-d)*18));break;
                    case "portal":d=Mathf.Abs(u*u+v*v-.45f);c=new Color(.50f,.38f,.75f,Mathf.Clamp01((.17f-d)*20));break;
                    case "camp":d=Mathf.Max(Mathf.Abs(u)*1.5f,Mathf.Abs(v));c=new Color(.90f,.61f,.23f,Mathf.Clamp01((.7f-d)*20));break;
                }
                tex.SetPixel(x,y,c);
            }
            tex.Apply();File.WriteAllBytes(Root+kind+".png",tex.EncodeToPNG());UnityEngine.Object.DestroyImmediate(tex);
        }
        public static string CreateTrial()
        {
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var camera=new GameObject("Cartoon trial camera").AddComponent<Camera>();camera.tag="MainCamera";
            camera.orthographic=true;camera.orthographicSize=5.12f;camera.transform.position=new Vector3(0,0,-10);
            camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.66f,.73f,.43f);camera.allowHDR=false;camera.allowMSAA=false;
            var ground=new GameObject("Garden — flat style approval background").AddComponent<SpriteRenderer>();ground.sprite=Load("garden");ground.sortingOrder=-10;
            var shadow=new GameObject("Contact shadow").AddComponent<SpriteRenderer>();shadow.sprite=Load("shadow");shadow.transform.position=new Vector3(0,-2.0f,.01f);shadow.transform.localScale=new Vector3(2.7f,.8f,1);shadow.sortingOrder=0;shadow.color=new Color(1,1,1,.25f);
            var pet=new GameObject("Pet").AddComponent<CartoonPetRig>();pet.source=Load("huyen-quy");pet.transform.position=new Vector3(0,-2,0);shadow.transform.SetParent(pet.transform,true);
            var canvas=new GameObject("Trial instructions",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler));canvas.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
            var scaler=canvas.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1280,850);
            var font=Resources.Load<TMP_FontAsset>("Fonts/NotoSans-TMP");
            Text(canvas.transform,font,"HUYỀN GIÁP QUY · MẪU CARTOON",new Vector2(20,-20),20,true);
            Text(canvas.transform,font,"WASD / phím mũi tên · Bấm sân để đi · R về điểm xuất phát",new Vector2(20,-48),16,true);
            EditorSceneManager.SaveScene(scene,Scene);AssetDatabase.SaveAssets();Selection.activeGameObject=pet.gameObject;
            var view=EditorWindow.GetWindow(typeof(EditorWindow).Assembly.GetType("UnityEditor.GameView"));view.Focus();
            return Scene;
        }
        private static void Text(Transform parent,TMP_FontAsset font,string value,Vector2 point,float size,bool top)
        {
            var go=new GameObject(value,typeof(RectTransform),typeof(TextMeshProUGUI));go.transform.SetParent(parent,false);
            var rect=(RectTransform)go.transform;rect.anchorMin=rect.anchorMax=rect.pivot=new Vector2(0,top?1:0);rect.anchoredPosition=point;rect.sizeDelta=new Vector2(1000,30);
            var text=go.GetComponent<TextMeshProUGUI>();text.font=font;text.fontSize=size;text.text=value;text.color=new Color(.13f,.17f,.23f);text.raycastTarget=false;
        }
        public static string BuildTrialWeb()
        {
            if(EditorApplication.isPlaying)throw new InvalidOperationException("Stop Play before building.");
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.WebGL,ScriptingImplementation.IL2CPP);
            PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Disabled;PlayerSettings.WebGL.decompressionFallback=false;
            PlayerSettings.SetGraphicsAPIs(BuildTarget.WebGL,new[]{GraphicsDeviceType.OpenGLES3});
            var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{Scene},target=BuildTarget.WebGL,locationPathName=Path.GetFullPath("WebBuild"),options=BuildOptions.None});
            if(report.summary.result!=BuildResult.Succeeded)throw new InvalidOperationException("Cartoon Web build failed.");
            var files=Directory.GetFiles("WebBuild/Build");string html=File.ReadAllText("Web/cartoon.html");string version=Guid.NewGuid().ToString("N");
            foreach(var pair in new[]{new[]{"__LOADER__",".loader.js"},new[]{"__DATA__",".data"},new[]{"__FRAMEWORK__",".framework.js"},new[]{"__WASM__",".wasm"}})
                html=html.Replace(pair[0],Path.GetFileName(files.Single(f=>f.EndsWith(pair[1],StringComparison.Ordinal)))+"?v="+version);
            File.WriteAllText("WebBuild/index.html",html);File.Copy("Assets/_Project/Resources/Fonts/OFL.txt","WebBuild/FONT-LICENSE.txt",true);
            string json=JsonUtility.ToJson(new BuildEvidence{success=true,seconds=report.summary.totalTime.TotalSeconds,bytes=report.summary.totalSize,errors=report.summary.totalErrors},true);
            File.WriteAllText("Verification/CartoonTrial/build.json",json+"\n");return json;
        }
        [Serializable] private sealed class BuildEvidence { public bool success;public double seconds;public ulong bytes;public int errors; }
    }
}
