# Bộ mẫu chibi góc nhìn cao

Ba PNG gốc được tạo bằng ImageGen tích hợp, theo ảnh Soul Strike được chủ dự án cung cấp: `hero.png`, `huyen-quy.png`, `field.png`. Nền được chỉnh thêm để giảm nét cỏ vụn. Prompt và đường dẫn nguồn nằm trong `generation-prompts.json`.

Unity importer dùng alpha, Bilinear, FullRect và PPU100; sprite người/thú tối đa 1024, nền tối đa 2048. Hai SpriteSkin dùng sáu bone với trọng số khác nhau cho người và quy. Đây là skin lưới từ bitmap một tư thế, chưa phải atlas nhiều hướng hoặc bộ clip chiến đấu hoàn chỉnh.

Builder: `Assets/_Project/Editor/CartoonArtBuilder.cs`. Runtime renderer: `CartoonCharacterRig`; input/follow preview: `CartoonTrialDirector`. Scene thử lưu qua Editor API. Main logic chỉ thay presentation, không sửa domain/save.
