# Quy tắc mỹ thuật v4 — chibi góc nhìn cao

Yêu cầu ngày 07/10/2026: dùng [Soul Strike](References/soul-strike-high-view.png) làm tham chiếu góc nhìn, tỷ lệ và cách phân cấp hình ảnh. Đây là mẫu để duyệt; thiết kế nhân vật và môi trường thuộc bối cảnh tu tiên của Linh Thú Ký.

- Góc nhìn từ cao xuống, quy ước khoảng 60–65 độ so với mặt đất trong bản vẽ: thấy đỉnh đầu, đỉnh mai và mặt trên vật thể; thân/chân bị rút ngắn. Camera Unity 2D vẫn nhìn thẳng mặt phẳng sprite, góc cao nằm trong thiết kế ảnh.
- Nhân vật chibi khoảng hai đầu, đầu chiếm gần nửa chiều cao, tóc thành vài khối rõ, thân ngắn và hai chân tách nhau. Ngự thú sư tóc bạc, áo xanh đen–trắng ngà, đai xanh ngọc, điểm vàng ít, kiếm ngắn. Hình phải đọc được khi hiển thị cao khoảng 55–85 px.
- Huyền Giáp Quy giữ mai than đen, ít đường hoa văn vàng, da xanh ngọc; mai thấy từ trên nhiều hơn thành bên. Không phủ nhiều trang sức hoặc chấm da vụn.
- Viền xanh đen gọn, cùng độ dày thị giác; tô 2–3 mảng sáng tối; ánh sáng trên trái và bóng xuống phải. Nét nhân vật rõ hơn nền. Không pixel, không mô hình bóng nhựa, không lông/tóc tả thực.
- Nền là mảng cỏ xanh rộng yên mắt, chỉ thỉnh thoảng có mảng xanh đậm/nhạt nhẹ; không rắc nét vụn hoặc texture nham nhở. Đá, cây, bụi cỏ tập trung ít cụm; phần giữa để trống cho nhân vật và chiến đấu.
- Góc nhìn và tỷ lệ phải đồng nhất giữa người, thú, đá và cây. Map rộng nhìn thoáng; tránh cổng lớn hoặc tán cây chắn cả trung tâm.
- PNG alpha cho người và thú; Bilinear, không mipmap ở cảnh thử cố định. Nền giữ tỷ lệ ảnh và crop theo viewport, không kéo méo nền hoặc nhân vật.
- Animation dùng cùng bitmap và khung xương riêng theo cơ thể người/thú; không sinh ảnh AI độc lập cho từng frame. Giữ mặt, kiếm và mai ổn định, chuyển động chân nhỏ.
- Tách tile/prop/collision khi xây map sản xuất; nền mẫu hiện là ảnh phẳng. Bóng tiếp xúc của nhân vật là sprite riêng; thứ tự vẽ theo vị trí chân.

## Mẫu hiện hành

`Assets/_Project/Art/CartoonV2/` có nền đồng cỏ, ngự thú sư và linh quy góc cao. Scene `CartoonArtTrial.unity` dùng hai SpriteSkin sáu bone; người được điều khiển ban đầu, thú đi theo; Tab đổi vai, R về điểm xuất phát. Renderer không sở hữu input hoặc dữ liệu lưu; controller preview không đọc/ghi save.

Scene logic `ThanDinhPrototype.unity` dùng ảnh người cho player/thần hồn và ảnh quy cho thú, với mesh motion Canvas nhẹ. Luật game, nghề, vật phẩm, dashboard và save schema giữ nguyên. Hình đang có trái/phải; chưa có bộ nhìn lên/xuống hoặc animation tấn công riêng.

## Duyệt mẫu và khôi phục

Đối chiếu góc nhìn, đầu/thân, viền và cỏ ở đúng kích thước chơi; xem idle/walk và đổi người/thú không mất chủ thể; compile và build phải thành công. Không kết luận FPS hay sức chứa online chỉ từ mẫu ảnh.

Art CartoonV1 được giữ nguyên để so sánh/quay lại. Source và hai scene trước chỉnh góc nhìn nằm ở `Verification/CartoonTrial/cartoon-v1-code-before-high-view.tgz`. Pixel/Aseprite cũ vẫn đã gỡ; bản nén pixel trước đó không phải asset đang dùng.
