-- Linh Thu Ky Garden V8: original native-resolution pixel clusters.
-- Every drawing layer stays editable. No interpolation, images, or imports.
local OUT = '/private/tmp/nguthu-garden-v8-props/'
local HEX = {}
for h in io.lines(OUT..'linhthu-v2.hex') do if h:match('^%x%x%x%x%x%x$') then HEX[#HEX+1]=h end end
local C = {}
for _,h in ipairs(HEX) do
  C[h] = app.pixelColor.rgba(tonumber(h:sub(1,2),16),tonumber(h:sub(3,4),16),tonumber(h:sub(5,6),16),255)
end
local function px(im,x,y,c)
  if x>=0 and x<im.width and y>=0 and y<im.height then im:drawPixel(x,y,C[c] or c) end
end
local function rect(im,x1,y1,x2,y2,c)
  for y=y1,y2 do for x=x1,x2 do px(im,x,y,c) end end
end
local function line(im,x1,y1,x2,y2,c)
  local dx,dy=math.abs(x2-x1),-math.abs(y2-y1)
  local sx,sy=x1<x2 and 1 or -1,y1<y2 and 1 or -1
  local err=dx+dy
  while true do
    px(im,x1,y1,c)
    if x1==x2 and y1==y2 then break end
    local e=2*err
    if e>=dy then err=err+dy; x1=x1+sx end
    if e<=dx then err=err+dx; y1=y1+sy end
  end
end
local function poly(im,p,c)
  local ymin,ymax=p[1][2],p[1][2]
  for _,v in ipairs(p) do ymin=math.min(ymin,v[2]); ymax=math.max(ymax,v[2]) end
  for y=ymin,ymax do
    local hits={}
    local scan=y+0.5
    for i,a in ipairs(p) do
      local b=p[i%#p+1]
      if (a[2]<=scan and b[2]>scan) or (b[2]<=scan and a[2]>scan) then
        hits[#hits+1]=a[1]+(scan-a[2])*(b[1]-a[1])/(b[2]-a[2])
      end
    end
    table.sort(hits)
    for i=1,#hits,2 do
      for x=math.ceil(hits[i]-0.5),math.floor(hits[i+1]-0.5) do px(im,x,y,c) end
    end
  end
  for i,a in ipairs(p) do local b=p[i%#p+1]; line(im,a[1],a[2],b[1],b[2],c) end
end
local function ellipse(im,cx,cy,rx,ry,c)
  for y=math.floor(cy-ry),math.ceil(cy+ry) do
    for x=math.floor(cx-rx),math.ceil(cx+rx) do
      if ((x-cx)/rx)^2+((y-cy)/ry)^2<=1 then px(im,x,y,c) end
    end
  end
end
local sprites,metadata={},{}
local function sprite(name,w,h)
  local s=Sprite(w,h,ColorMode.RGB)
  s.layers[1].name='Empty construction layer'
  local p=Palette(#HEX)
  for i,hx in ipairs(HEX) do p:setColor(i-1,Color{r=tonumber(hx:sub(1,2),16),g=tonumber(hx:sub(3,4),16),b=tonumber(hx:sub(5,6),16),a=255}) end
  s:setPalette(p)
  s.gridBounds=Rectangle(0,0,16,16)
  s.data='Original Garden V8 pixel art; native Lua-authored clusters; locked linhthu-v2 palette.'
  return s
end
local function layer(s,name,draw)
  local l=s:newLayer(); l.name=name
  local im=Image(s.width,s.height,ColorMode.RGB)
  im:clear()
  draw(im)
  s:newCel(l,1,im,Point(0,0))
end
local function finish(s,name,pivot,maxcolors,role)
  s:deleteLayer('Empty construction layer')
  local sl=s:newSlice(Rectangle(0,0,s.width,s.height))
  sl.name=name; sl.pivot=Point(pivot[1],pivot[2]); sl.data='pivotPixelsTopLeft; PPU=16'
  s:saveAs(OUT..name..'.aseprite')
  s:saveCopyAs(OUT..name..'.png')
  local im=Image(s)
  local used={}; local alphas={}; local opaque=0
  for it in im:pixels() do
    local v=it(); local a=app.pixelColor.rgbaA(v)
    alphas[a]=true
    assert(a==0 or a==255,name..' has non-binary alpha')
    if a==255 then used[v]=true; opaque=opaque+1 end
  end
  local colors=0; for _ in pairs(used) do colors=colors+1 end
  assert(colors<=maxcolors,name..' exceeds color limit')
  local names={}; for _,l in ipairs(s.layers) do names[#names+1]=l.name end
  metadata[#metadata+1]={id=name,png=name..'.png',source=name..'.aseprite',width=s.width,height=s.height,pivotPixelsTopLeft={x=pivot[1],y=pivot[2]},pixelsPerUnit=16,frames=1,colors=colors,colorLimit=maxcolors,alpha='0/255',layers=names,role=role,origin='Original hand-authored integer-coordinate Aseprite Lua pixel clusters',unityImported=false}
  sprites[#sprites+1]=s
  print(name..' '..s.width..'x'..s.height..' colors='..colors..' layers='..#names..' opaque='..opaque)
end

-- Paving: matte warm stone; restrained green-grey mortar. Three distinct layouts.
do
  local s=sprite('paving-slab',32,32)
  layer(s,'01 - Grey green mortar',function(im) rect(im,0,0,31,31,'b1ad87') end)
  layer(s,'02 - Large stone slab',function(im)
    poly(im,{{4,1},{27,1},{30,4},{30,24},{28,24},{28,29},{5,30},{2,27},{1,6}},'e8ddb6')
  end)
  layer(s,'03 - Bevel and depth',function(im)
    poly(im,{{4,1},{27,1},{28,2},{5,2},{2,6},{2,20},{1,20},{1,6}},'f7f0d8')
    poly(im,{{29,5},{30,5},{30,24},{28,24},{28,29},{5,30},{3,28},{25,28},{27,26},{27,23},{29,23}},'8e8a6e')
    poly(im,{{27,22},{29,22},{29,23},{27,25}},'b1ad87')
  end)
  finish(s,'paving-slab',{16,16},16,'opaque ground tile')
end
do
  local s=sprite('paving-split',32,32)
  layer(s,'01 - Grey green mortar',function(im) rect(im,0,0,31,31,'b1ad87') end)
  layer(s,'02 - Three fitted stones',function(im)
    poly(im,{{2,1},{13,1},{15,3},{15,27},{13,30},{3,30},{1,28},{1,4}},'e8ddb6')
    poly(im,{{19,1},{28,1},{30,3},{30,15},{28,17},{18,17},{17,15},{17,4}},'e8ddb6')
    poly(im,{{18,19},{28,19},{30,22},{30,29},{28,30},{18,30},{17,28},{17,21}},'e8ddb6')
  end)
  layer(s,'03 - Fitted stone bevels',function(im)
    line(im,3,1,13,1,'f7f0d8'); line(im,1,5,1,25,'f7f0d8')
    line(im,19,1,28,1,'f7f0d8'); line(im,17,5,17,14,'f7f0d8')
    line(im,19,19,27,19,'f7f0d8'); line(im,17,22,17,27,'f7f0d8')
    poly(im,{{14,5},{15,5},{15,27},{13,30},{3,30},{3,29},{12,29},{14,26}},'8e8a6e')
    poly(im,{{29,5},{30,5},{30,15},{28,17},{19,17},{19,16},{28,16},{29,14}},'8e8a6e')
    poly(im,{{29,23},{30,23},{30,29},{28,30},{19,30},{19,29},{28,29},{29,28}},'8e8a6e')
  end)
  finish(s,'paving-split',{16,16},16,'opaque ground tile')
end
do
  local s=sprite('paving-petal',32,32)
  layer(s,'01 - Grey green mortar',function(im) rect(im,0,0,31,31,'b1ad87') end)
  layer(s,'02 - Offset stone pair',function(im)
    poly(im,{{3,1},{27,1},{30,4},{30,11},{28,14},{4,14},{1,12},{1,5}},'e8ddb6')
    poly(im,{{4,16},{27,16},{29,18},{30,28},{28,30},{3,30},{1,28},{1,19}},'e8ddb6')
  end)
  layer(s,'03 - Stone bevels',function(im)
    line(im,4,1,26,1,'f7f0d8'); line(im,1,6,1,10,'f7f0d8')
    line(im,5,16,26,16,'f7f0d8'); line(im,1,20,1,26,'f7f0d8')
    poly(im,{{29,5},{30,5},{30,11},{28,14},{4,14},{3,13},{27,13},{29,10}},'8e8a6e')
    poly(im,{{28,20},{29,20},{30,28},{28,30},{3,30},{3,29},{27,29},{28,27}},'8e8a6e')
  end)
  layer(s,'04 - Three resting petals',function(im)
    poly(im,{{21,6},{24,5},{25,6},{24,8},{21,8},{20,7}},'e6a0b3')
    line(im,21,6,23,6,'f6ced6'); px(im,24,8,'b86a86')
    poly(im,{{25,21},{27,21},{28,23},{27,25},{25,24},{24,22}},'e6a0b3')
    line(im,25,21,26,22,'f6ced6'); line(im,26,24,27,24,'b86a86')
    poly(im,{{19,25},{21,25},{22,26},{21,27},{18,27},{18,26}},'e6a0b3')
    line(im,19,25,20,25,'f6ced6')
  end)
  finish(s,'paving-petal',{16,16},16,'opaque ground tile with sparse fallen petals')
end

-- Three bamboo culms with asymmetrical fans of broad lanceolate leaves.
do
  local s=sprite('bamboo',48,80)
  layer(s,'01 - Compact ground shadow',function(im) ellipse(im,24,74,16,3,'2f5a4b') end)
  layer(s,'02 - Rear leaf silhouettes',function(im)
    poly(im,{{23,21},{18,13},{14,7},{14,13},{17,20},{21,25}},'2f5a4b')
    poly(im,{{23,21},{27,12},{32,5},{32,12},{28,20}},'2f5a4b')
    poly(im,{{11,41},{7,32},{3,26},{3,33},{7,40}},'2f5a4b')
    poly(im,{{37,38},{42,27},{46,23},{45,31},{41,37}},'2f5a4b')
    poly(im,{{27,51},{31,45},{36,42},{35,48},{29,54}},'4c8063')
  end)
  layer(s,'03 - Bamboo culm contours',function(im)
    poly(im,{{23,10},{27,10},{27,34},{26,58},{26,74},{21,74},{21,57},{22,34}},'2f5a4b')
    poly(im,{{9,28},{13,27},{15,49},{17,73},{12,75},{11,51}},'2f5a4b')
    poly(im,{{35,23},{39,24},{38,44},{36,60},{35,74},{30,73},{32,59},{34,43}},'2f5a4b')
  end)
  layer(s,'04 - Green culm planes',function(im)
    poly(im,{{24,11},{26,11},{26,34},{25,58},{25,73},{22,73},{22,57},{23,34}},'83b865')
    poly(im,{{10,29},{12,28},{14,49},{16,72},{13,73},{12,51}},'83b865')
    poly(im,{{36,25},{38,25},{37,44},{35,60},{34,73},{31,72},{33,59},{35,43}},'83b865')
    line(im,24,12,24,33,'b4d67e'); line(im,23,36,23,56,'b4d67e'); line(im,22,60,22,71,'b4d67e')
    line(im,10,31,11,49,'b4d67e'); line(im,12,53,14,70,'b4d67e')
    line(im,36,27,35,43,'b4d67e'); line(im,34,46,32,59,'b4d67e'); line(im,32,62,31,70,'b4d67e')
    line(im,26,14,26,32,'4c8063'); line(im,25,36,25,56,'4c8063'); line(im,25,60,25,72,'4c8063')
  end)
  layer(s,'05 - Culm nodes and branches',function(im)
    rect(im,22,33,27,34,'2f5a4b'); rect(im,22,34,26,34,'b1ad87')
    rect(im,21,57,26,58,'2f5a4b'); rect(im,22,57,25,57,'b1ad87')
    line(im,11,50,15,49,'2f5a4b'); line(im,12,51,15,50,'b1ad87')
    line(im,33,44,38,45,'2f5a4b'); line(im,34,45,37,45,'b1ad87')
    line(im,31,60,36,61,'2f5a4b'); line(im,32,61,35,61,'b1ad87')
    line(im,24,22,8,15,'2f5a4b'); line(im,24,23,40,15,'2f5a4b')
    line(im,12,40,3,39,'2f5a4b'); line(im,13,40,23,35,'2f5a4b')
    line(im,36,39,46,37,'2f5a4b'); line(im,35,42,26,37,'2f5a4b')
    line(im,24,57,7,57,'2f5a4b'); line(im,25,58,41,53,'2f5a4b')
  end)
  layer(s,'06 - Large leaf fans',function(im)
    local fans={
      {{22,22},{13,15},{6,14},{11,19},{19,23}},
      {{18,19},{13,9},{8,5},{9,13},{14,20}},
      {{16,19},{8,19},{2,23},{10,23},{18,22}},
      {{25,22},{32,16},{42,13},{36,19},{28,24}},
      {{29,20},{34,9},{39,4},{38,12},{33,21}},
      {{31,21},{40,21},{46,25},{38,25},{29,24}},
      {{12,40},{7,34},{2,33},{5,38},{11,42}},
      {{14,40},{19,30},{24,27},{22,33},{16,41}},
      {{15,40},{22,38},{27,40},{22,42},{16,42}},
      {{35,40},{30,31},{26,28},{26,34},{32,41}},
      {{36,41},{41,34},{46,33},{44,39},{38,43}},
      {{36,43},{43,43},{46,47},{40,47},{35,45}},
      {{22,57},{14,50},{7,48},{11,54},{20,59}},
      {{18,57},{9,55},{2,57},{9,60},{18,59}},
      {{18,59},{11,66},{6,70},{8,63},{14,58}},
      {{25,57},{31,49},{36,46},{34,53},{27,60}},
      {{27,58},{38,52},{45,52},{40,57},{29,61}},
      {{31,59},{39,60},{45,65},{36,63},{28,61}}
    }
    for _,p in ipairs(fans) do poly(im,p,'2f5a4b') end
    poly(im,{{21,21},{13,16},{9,15},{13,19},{19,22}},'83b865')
    poly(im,{{17,18},{13,11},{10,8},{11,13},{15,19}},'83b865')
    poly(im,{{15,20},{8,20},{5,22},{10,22},{16,21}},'4c8063')
    poly(im,{{27,22},{33,17},{39,15},{35,18},{28,23}},'83b865')
    poly(im,{{31,19},{35,11},{37,8},{36,13},{33,19}},'83b865')
    poly(im,{{32,22},{39,22},{43,24},{38,24},{31,23}},'4c8063')
    poly(im,{{11,40},{7,35},{4,35},{6,38},{10,40}},'83b865')
    poly(im,{{15,38},{20,31},{22,30},{20,34},{16,39}},'83b865')
    poly(im,{{17,40},{21,39},{24,40},{21,41},{17,41}},'4c8063')
    poly(im,{{33,39},{29,32},{27,30},{28,34},{32,39}},'83b865')
    poly(im,{{38,40},{42,35},{44,35},{42,38},{38,41}},'83b865')
    poly(im,{{37,44},{42,44},{44,46},{40,46},{37,45}},'4c8063')
    poly(im,{{20,57},{14,52},{10,50},{12,54},{19,58}},'83b865')
    poly(im,{{16,57},{9,56},{5,57},{10,59},{16,58}},'83b865')
    poly(im,{{15,60},{11,65},{8,67},{10,63},{14,60}},'4c8063')
    poly(im,{{26,57},{31,51},{34,49},{32,53},{27,58}},'83b865')
    poly(im,{{29,58},{38,53},{42,53},{38,56},{30,59}},'83b865')
    poly(im,{{31,60},{38,61},{42,63},{36,62}},'4c8063')
  end)
  finish(s,'bamboo',{24,76},20,'isolated foliage prop')
end

-- Jade medicinal herb: four broad leaves and one restrained jade bud.
do
  local s=sprite('spirit-herb',24,32)
  layer(s,'01 - Ground shadow',function(im) ellipse(im,12,28,9,2,'2f5a4b') end)
  layer(s,'02 - Stem and leaf contours',function(im)
    poly(im,{{11,12},{13,12},{14,29},{10,29}},'263046')
    poly(im,{{11,24},{7,23},{3,19},{2,14},{7,15},{11,19}},'263046')
    poly(im,{{13,22},{15,15},{21,11},{21,17},{18,22},{14,25}},'263046')
    poly(im,{{11,27},{6,28},{2,26},{3,22},{8,23}},'263046')
    poly(im,{{13,27},{17,23},{22,22},{21,27},{17,29}},'263046')
  end)
  layer(s,'03 - Jade leaf planes',function(im)
    rect(im,11,15,12,28,'4c8063')
    poly(im,{{10,22},{7,21},{4,18},{3,16},{7,17},{10,20}},'3fa88b')
    poly(im,{{14,22},{16,16},{20,13},{20,17},{17,21},{14,23}},'3fa88b')
    poly(im,{{10,26},{6,27},{3,25},{4,23},{8,24}},'3fa88b')
    poly(im,{{14,27},{18,24},{20,24},{20,26},{17,28}},'3fa88b')
    line(im,4,17,8,20,'b4d67e'); line(im,19,14,16,18,'b4d67e')
    line(im,4,24,8,25,'83b865'); line(im,17,25,20,24,'83b865')
  end)
  layer(s,'04 - Jade bud contour',function(im)
    poly(im,{{12,2},{16,7},{15,12},{12,15},{8,12},{7,8}},'263046')
  end)
  layer(s,'05 - Jade bud and collar',function(im)
    poly(im,{{12,3},{15,7},{14,11},{12,13},{9,11},{8,8}},'3fa88b')
    poly(im,{{12,4},{13,7},{11,10},{9,10},{9,8}},'8fcbe0')
    line(im,12,4,10,7,'cfeff5')
    line(im,10,13,13,13,'f1c86d'); px(im,11,14,'c98b4a')
  end)
  finish(s,'spirit-herb',{12,29},16,'isolated interactive jade herb')
end

-- Mineral ore: three rock planes, large jade outcrops, no sparkle confetti.
do
  local s=sprite('jade-ore',32,32)
  layer(s,'01 - Ground shadow',function(im) ellipse(im,16,27,13,3,'41405d') end)
  layer(s,'02 - Rock contour',function(im)
    poly(im,{{5,12},{14,7},{23,9},{28,16},{29,24},{25,28},{10,29},{3,24},{3,17}},'263046')
  end)
  layer(s,'03 - Three rock faces',function(im)
    poly(im,{{6,13},{14,8},{22,10},{27,16},{18,20},{4,18}},'899cbd')
    poly(im,{{4,19},{18,21},{17,27},{10,28},{4,24}},'55678f')
    poly(im,{{19,21},{27,17},{28,24},{24,27},{18,27}},'3f4d70')
    poly(im,{{7,13},{14,9},{21,10},{15,11},{9,15}},'e8ddb6')
  end)
  layer(s,'04 - Jade crystal contours',function(im)
    poly(im,{{13,12},{14,5},{18,2},{21,7},{20,14},{17,17}},'263046')
    poly(im,{{20,15},{22,8},{25,6},{28,11},{26,17},{23,19}},'263046')
    poly(im,{{6,22},{7,17},{11,14},{14,18},{13,24},{9,26}},'263046')
  end)
  layer(s,'05 - Jade crystal planes',function(im)
    poly(im,{{14,12},{15,6},{18,3},{18,13},{17,15}},'8fcbe0')
    poly(im,{{19,5},{20,7},{19,13},{18,15},{18,7}},'3fa88b')
    line(im,16,7,18,4,'cfeff5')
    poly(im,{{21,15},{23,9},{25,7},{25,15},{23,17}},'3fa88b')
    poly(im,{{26,9},{27,11},{25,16},{25,11}},'4c8063')
    line(im,23,10,25,8,'8fcbe0')
    poly(im,{{7,22},{8,18},{11,15},{11,22},{9,24}},'3fa88b')
    poly(im,{{12,17},{13,18},{12,23},{10,24},{11,21}},'4c8063')
    line(im,8,19,10,17,'8fcbe0')
  end)
  finish(s,'jade-ore',{16,28},16,'isolated interactive three-face jade ore')
end

-- Egg: warm stone-like shell, a single jade seal and two curved motifs.
do
  local s=sprite('spirit-egg',24,32)
  layer(s,'01 - Ground shadow',function(im) ellipse(im,12,29,9,1,'41405d') end)
  layer(s,'02 - Egg contour',function(im)
    poly(im,{{11,3},{14,3},{17,7},{19,12},{21,18},{21,23},{19,27},{16,29},{9,29},{5,27},{3,23},{3,18},{5,12},{8,6}},'263046')
  end)
  layer(s,'03 - Shell body',function(im)
    poly(im,{{11,4},{14,4},{16,7},{18,12},{20,18},{20,23},{18,26},{15,28},{9,28},{6,26},{4,22},{4,18},{6,12},{9,6}},'e8ddb6')
    poly(im,{{11,5},{13,5},{14,9},{14,15},{10,19},{5,20},{5,17},{7,12},{9,7}},'f7f0d8')
    poly(im,{{17,11},{18,12},{20,18},{20,23},{18,26},{15,28},{9,28},{7,26},{15,26},{18,22},{18,17}},'b1ad87')
    poly(im,{{10,7},{12,6},{12,9},{10,12},{8,13},{8,11}},'fdfbf2')
  end)
  layer(s,'04 - Restrained jade seal',function(im)
    poly(im,{{12,13},{16,17},{12,21},{8,17}},'4c8063')
    poly(im,{{12,14},{15,17},{12,20},{9,17}},'3fa88b')
    line(im,12,15,10,17,'8fcbe0'); line(im,12,16,13,17,'f1c86d')
    line(im,6,15,6,17,'3fa88b'); line(im,6,18,7,19,'3fa88b')
    line(im,17,20,18,18,'4c8063'); line(im,17,21,15,23,'4c8063')
  end)
  finish(s,'spirit-egg',{12,30},16,'isolated interactive spirit egg')
end

-- Aseprite-native contact sheets. Preview resampling uses exact 4x duplication.
local sheet=Image(312,104,ColorMode.RGB)
sheet:clear(C['83b865'])
local positions={{8,56},{52,56},{96,56},{140,8},{200,56},{236,56},{280,56}}
for i,s in ipairs(sprites) do
  local art=Image(s)
  for it in art:pixels() do
    local v=it()
    if app.pixelColor.rgbaA(v)==255 then
      sheet:drawPixel(positions[i][1]+it.x,positions[i][2]+it.y,v)
    end
  end
end
sheet:saveAs(OUT..'contact-sheet-native.png')
local big=Image(sheet.width*4,sheet.height*4,ColorMode.RGB)
for it in sheet:pixels() do local v=it(); for yy=0,3 do for xx=0,3 do big:drawPixel(it.x*4+xx,it.y*4+yy,v) end end end
big:saveAs(OUT..'contact-sheet-4x.png')
local f=assert(io.open(OUT..'assets.json','w'))
f:write(json.encode({version='garden-v8-props',palette='linhthu-v2.hex',coordinateOrigin='top-left',pixelsPerUnit=16,sourceScript='create-props.lua',assets=metadata})); f:write('\n'); f:close()
print('Saved seven .aseprite sources, seven PNGs, assets.json, and native + 4x contact sheets.')
