-- Reopen native sources, verify editable layers/pivots and exported composites.
local out='/private/tmp/nguthu-garden-v8-props/'
local f=assert(io.open(out..'assets.json'))
local meta=json.decode(f:read('*a')); f:close()
local report={}
for _,a in ipairs(meta.assets) do
  local s=app.open(out..a.source)
  assert(s.width==a.width and s.height==a.height,a.id..' dimensions')
  assert(#s.frames==1,a.id..' frames')
  assert(#s.layers==#a.layers,a.id..' layers')
  local sl=s.slices[1]
  assert(sl.pivot.x==a.pivotPixelsTopLeft.x and sl.pivot.y==a.pivotPixelsTopLeft.y,a.id..' pivot')
  for _,l in ipairs(s.layers) do
    assert(l.isVisible and l.opacity==255,a.id..' hidden/nonopaque layer')
    local cel=l:cel(1); assert(cel,a.id..' missing cel')
    for it in cel.image:pixels() do
      local alpha=app.pixelColor.rgbaA(it())
      assert(alpha==0 or alpha==255,a.id..' layer alpha')
    end
  end
  local expected=Image{fromFile=out..a.png}
  assert(Image(s):isEqual(expected),a.id..' source/export mismatch')
  report[#report+1]={id=a.id,layers=#s.layers,pivot={sl.pivot.x,sl.pivot.y},sourceExportIdentical=true,binaryLayerAlpha=true}
  print(a.id..' reopened: layers='..#s.layers..', pivot='..sl.pivot.x..','..sl.pivot.y..', PNG matches')
  s:close()
end
local g=assert(io.open(out..'native-audit.json','w'))
g:write(json.encode(report)); g:write('\n'); g:close()
