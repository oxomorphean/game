# Linh Thú Ký — Garden V8 props

Bảy thiết kế gốc, vẽ bằng cụm pixel có tọa độ integer trong Lua và render qua Aseprite MCP `run_lua_script`. Không dùng ảnh AI, ảnh tải hoặc ảnh lớn thu nhỏ. Palette khóa: `linhthu-v2.hex` của dự án, 34 màu; mỗi asset chỉ dùng một tập con. Ánh sáng trên trái; góc orthographic nhìn cao từ phía trước.

| Asset | Canvas | Pivot pixel từ top-left | Màu dùng / giới hạn | Layer editable |
| --- | --- | --- | --- | --- |
| paving-slab | 32×32 | 16,16 | 4 / 16 | 3 |
| paving-split | 32×32 | 16,16 | 4 / 16 | 3 |
| paving-petal | 32×32 | 16,16 | 7 / 16 | 4 |
| bamboo | 48×80 | 24,76 | 5 / 20 | 6 |
| spirit-herb | 24×32 | 12,29 | 10 / 16 | 5 |
| jade-ore | 32×32 | 16,28 | 10 / 16 | 5 |
| spirit-egg | 24×32 | 12,30 | 10 / 16 | 4 |

Mỗi asset có `.png` và `.aseprite`, một frame. Cả pixel alpha và opacity layer đều chỉ dùng 0/255. Tile có PNG opaque hoàn toàn; prop có nền trong suốt. `assets.json` lưu kích thước, layer, số màu và pivot. Aseprite lưu pivot bằng slice toàn canvas. PPU đề xuất 16; Unity normalized pivot tính `x/width, 1-y/height` từ tọa độ top-left trong metadata.

Contact sheet (thứ tự từ trái sang phải): paving-slab, paving-split, paving-petal, bamboo, spirit-herb, jade-ore, spirit-egg. `contact-sheet-native.png` là bản 1×; `contact-sheet-4x.png` nhân pixel đúng 4×, không nội suy.

Đã xem ở 1× và 4×. Sửa hai lỗi trong lần kiểm tra đầu: bóng trứng chạm mép canvas và contact sheet ghi alpha trong suốt đè nền. Không có Unity/C#/Assets thay đổi từ công việc phụ này. Chưa kiểm tra tỷ lệ hoặc occlusion trong Unity; main nhập và ráp cùng bộ sân/cỏ/nhân vật.

## Kiểm chứng

`pixel-validation.json`: validator dự án chạy với palette v2 và `--strict`, 7 PASS, 0 WARN, 0 FAIL. `native-audit.json`: mở lại cả bảy file `.aseprite`, xác nhận canvas, một frame, layer editable visible, binary alpha từng cel, slice pivot đúng metadata, PNG trùng composite nguồn.

Nguồn tái tạo: `create-props.lua`. Script audit: `verify-native.lua`. Chạy chúng trong Aseprite bằng `dofile('/private/tmp/nguthu-garden-v8-props/create-props.lua')` và `dofile('/private/tmp/nguthu-garden-v8-props/verify-native.lua')`. Script hiện ghi vào đường dẫn tạm này; đổi hằng `OUT`/`out` nếu di chuyển nguồn.
