-- Original Linh Thu Ky cultivator and quiet meadow clusters. Native Aseprite pixels.
local out='/private/tmp/nguthu-garden-v8-main/'
local palette={}
for h in io.lines('/Users/nguyenhoangdacdat/dev/nguthu-unity-demo/ArtDirection/Palette/linhthu-v2.hex') do palette[#palette+1]=h end
local hex={O='263046',hair='1b1f2e',hs='41405d',hl='3f4d70',skin='f2c9a8',ss='b8805c',cream='f7f0d8',white='fdfbf2',robe='3fa88b',rd='2f5a4b',rs='4c8063',rl='83b865',pink='b86a86',gold='f1c86d',gd='c98b4a',grass='83b865',shade='79aa5e',leaf='4c8063',leafL='b4d67e'}
local C={}
for k,h in pairs(hex) do C[k]=app.pixelColor.rgba(tonumber(h:sub(1,2),16),tonumber(h:sub(3,4),16),tonumber(h:sub(5,6),16),255) end
local function setup(w,h)
 local s=Sprite(w,h,ColorMode.RGB);local p=Palette(#palette)
 for i,v in ipairs(palette) do p:setColor(i-1,Color{r=tonumber(v:sub(1,2),16),g=tonumber(v:sub(3,4),16),b=tonumber(v:sub(5,6),16),a=255}) end
 s:setPalette(p);return s
end
local function px(im,x,y,col) if x>=0 and x<im.width and y>=0 and y<im.height then im:putPixel(x,y,C[col]) end end
local function rect(im,x,y,w,h,col) for yy=y,y+h-1 do for xx=x,x+w-1 do px(im,xx,yy,col) end end end
local function line(im,x,y,u,v,col)
 local dx,dy=math.abs(u-x),math.abs(v-y);local sx,sy=x<u and 1 or -1,y<v and 1 or -1;local e=dx-dy
 while true do px(im,x,y,col);if x==u and y==v then break end;local e2=e*2;if e2>-dy then e=e-dy;x=x+sx end;if e2<dx then e=e+dx;y=y+sy end end
end
local function poly(im,pts,col,edge)
 for y=0,im.height-1 do local xs={}
  for i,a in ipairs(pts) do local b=pts[i%#pts+1];if (a[2]<=y and b[2]>y) or (b[2]<=y and a[2]>y) then xs[#xs+1]=a[1]+(y-a[2])*(b[1]-a[1])/(b[2]-a[2]) end end
  table.sort(xs);for i=1,#xs-1,2 do for x=math.ceil(xs[i]),math.floor(xs[i+1]) do px(im,x,y,col) end end
 end
 if edge then for i,a in ipairs(pts) do local b=pts[i%#pts+1];line(im,a[1],a[2],b[1],b[2],edge) end end
end
local function at(pts,dx,dy) local r={};for _,p in ipairs(pts) do r[#r+1]={p[1]+dx,p[2]+dy} end;return r end
local s=setup(32,48)
local names={'01 Back hair','02 Shoes','03 Jade robe','04 Sleeves and hands','05 Head','06 Gold sash'}
local layers={}
for i,n in ipairs(names) do local l=i==1 and s.layers[1] or s:newLayer();l.name=n;layers[i]=l end
for i=2,30 do s:newEmptyFrame() end
local stride={-1,0,1,1,0,-1};local lift={0,-1,-1,0,0,0}
for f=1,30 do
 local dir=math.floor((f-1)/10);local k=(f-1)%10+1;local walk=k>=5;local step=walk and k-4 or 1
 local bob=(walk and (step==2 or step==5) or not walk and k==2) and -1 or 0
 local a=walk and stride[step] or 0;local b=-a;local la=walk and lift[step] or 0;local lb=walk and lift[(step+2)%6+1] or 0;local blink=not walk and k==3
 local ims={};for i=1,#layers do ims[i]=Image(32,48,ColorMode.RGB) end
 local back,feet,robe,arm,head,belt=table.unpack(ims)
 if dir==0 or dir==1 then
  -- Compact black hair and fixed topknot; rear ribbons separate from torso.
  poly(back,at({{8,17},{24,17},{25,30},{22,34},{20,31},{12,31},{9,34},{7,30}},0,bob),'hair','O')
  poly(back,at({{8,22},{10,23},{11,31},{9,33},{8,30}},0,bob),'hl',nil)
  rect(feet,10+a,39+la,5,5,'O');rect(feet,18+b,39+lb,5,5,'O');rect(feet,11+a,40+la,3,2,'hs');rect(feet,19+b,40+lb,3,2,'hs')
  poly(robe,at({{11,27},{20,27},{24,32},{25,40},{23,42},{8,42},{6,40},{8,32}},0,bob),'rs','O')
  poly(robe,at({{11,28},{19,28},{22,33},{23,40},{19,41},{9,41},{8,39},{10,33}},0,bob),'robe',nil)
  poly(robe,at({{11,29},{14,30},{14,35},{10,39},{8,39},{10,33}},0,bob),'rl',nil)
  if dir==0 then
   poly(robe,at({{12,27},{20,27},{16,33}},0,bob),'cream',nil);line(robe,12,28+bob,15,32+bob,'white');line(robe,19,28+bob,16,34+bob,'rd')
   line(robe,15,35+bob,12,40+bob,'rd');line(robe,21,37+bob,22,39+bob,'rs')
  else
   line(robe,17,30+bob,19,39+bob,'rd');line(robe,9,39+bob,14,40+bob,'rl')
   poly(back,at({{12,24},{20,24},{21,30},{18,33},{16,30},{14,33},{11,30}},0,bob),'hair','O')
  end
  poly(arm,at({{8,29},{11,31},{9,35},{6,37},{3,35},{4,31}},a,bob),'rs','O')
  poly(arm,at({{5,31},{8,30},{9,32},{7,35},{5,35}},a,bob),'robe',nil)
  poly(arm,at({{22,29},{25,31},{28,35},{25,37},{22,35},{20,31}},b,bob),'rd','O')
  poly(arm,at({{23,31},{25,32},{26,35},{24,35},{22,33}},b,bob),'robe',nil)
  rect(arm,5+a,36+bob,3,2,'skin');rect(arm,23+b,36+bob,3,2,'skin')
  poly(head,at({{9,10},{12,8},{20,8},{24,11},{26,16},{26,23},{23,27},{10,27},{6,23},{6,16}},0,bob),'hair','O')
  poly(head,at({{8,12},{12,10},{20,10},{23,12},{24,15},{19,15},{15,13},{10,16},{7,16}},0,bob),'hl',nil)
  poly(head,at({{13,6},{15,5},{18,5},{20,7},{20,10},{13,10}},0,bob),'hair','O');line(head,14,6+bob,17,6+bob,'hl')
  rect(head,13,9+bob,7,1,'gold');px(head,14,8+bob,'gd')
  if dir==0 then
   poly(head,at({{9,16},{12,14},{16,16},{20,14},{24,17},{24,22},{21,26},{12,26},{9,23}},0,bob),'skin',nil)
   poly(head,at({{21,17},{24,18},{24,22},{21,26},{18,26},{20,23}},0,bob),'ss',nil)
   -- Eyes have deliberate white and two-pixel pupils, not glossy shading.
   if blink then line(head,11,21+bob,13,21+bob,'O');line(head,19,21+bob,21,21+bob,'O')
   else rect(head,10,19+bob,4,4,'O');rect(head,18,19+bob,4,4,'O');px(head,11,19+bob,'white');px(head,19,19+bob,'white');rect(head,12,22+bob,2,1,'hl');rect(head,20,22+bob,2,1,'hl') end
   px(head,10,23+bob,'pink');px(head,23,23+bob,'pink');line(head,15,25+bob,17,25+bob,'ss')
   poly(head,at({{8,13},{12,12},{17,13},{16,16},{14,18},{13,15},{11,17},{8,18}},0,bob),'hair',nil)
   poly(head,at({{18,12},{23,13},{24,17},{21,18},{20,16},{19,17}},0,bob),'hair',nil)
   line(head,9,13+bob,12,12+bob,'hl')
  else
   poly(head,at({{9,14},{14,12},{21,13},{24,17},{24,23},{21,26},{11,26},{8,23}},0,bob),'hs',nil)
   poly(head,at({{9,14},{14,12},{20,13},{22,15},{17,14},{13,15},{9,19}},0,bob),'hl',nil)
   poly(head,at({{8,18},{13,17},{14,24},{17,26},{12,26},{9,24}},0,bob),'hair',nil)
  end
  rect(belt,10,34+bob,12,2,'rd');rect(belt,15,34+bob,3,2,'gold');px(belt,15,34+bob,'cream')
  poly(belt,at({{18,35},{20,35},{19,40},{17,40}},0,bob),'cream',nil)
 else
  -- Side view is drawn independently; left uses a horizontal flip of this symmetric design.
  poly(back,at({{7,15},{17,13},{21,20},{19,29},{16,33},{10,32},{7,28}},0,bob),'hair','O')
  rect(feet,11+b,39+lb,5,5,'O');rect(feet,18+a,39+la,6,5,'O');rect(feet,12+b,40+lb,3,2,'hs');rect(feet,19+a,40+la,4,2,'hs')
  poly(robe,at({{13,27},{20,27},{23,32},{24,40},{21,42},{9,42},{8,40},{10,32}},0,bob),'rs','O')
  poly(robe,at({{14,28},{20,29},{21,33},{22,40},{17,41},{10,40},{12,32}},0,bob),'robe',nil)
  poly(robe,at({{13,29},{15,29},{16,35},{13,40},{10,40}},0,bob),'rl',nil)
  poly(robe,at({{19,28},{22,30},{20,33},{18,31}},0,bob),'cream',nil)
  poly(arm,at({{13,29},{17,30},{19,35},{16,38},{12,36},{10,32}},a,bob),'rs','O')
  poly(arm,at({{12,31},{15,30},{17,33},{17,36},{14,36},{12,34}},a,bob),'robe',nil)
  rect(arm,15+a,37+bob,3,2,'skin')
  poly(head,at({{11,10},{17,8},{22,10},{24,14},{25,18},{27,20},{26,23},{23,26},{14,27},{9,24},{7,18},{8,13}},0,bob),'hair','O')
  poly(head,at({{10,12},{16,10},{21,11},{23,13},{19,13},{15,15},{10,18},{8,17}},0,bob),'hl',nil)
  poly(head,at({{17,14},{22,14},{23,18},{25,19},{26,21},{24,24},{20,26},{16,25},{14,21}},0,bob),'skin',nil)
  poly(head,at({{24,21},{25,21},{24,24},{20,26},{18,25},{21,23}},0,bob),'ss',nil)
  poly(head,at({{15,6},{17,5},{20,6},{21,9},{20,11},{14,10}},0,bob),'hair','O');line(head,16,6+bob,19,6+bob,'hl');rect(head,14,10+bob,7,1,'gold')
  poly(head,at({{14,13},{19,12},{23,14},{22,17},{20,16},{18,18},{17,16},{14,20},{13,18}},0,bob),'hair',nil)
  if blink then line(head,21,20+bob,23,20+bob,'O') else rect(head,21,18+bob,3,4,'O');px(head,21,18+bob,'white');px(head,23,21+bob,'hl') end
  px(head,24,23+bob,'pink');line(head,22,25+bob,24,24+bob,'ss')
  rect(belt,11,34+bob,11,2,'rd');rect(belt,19,34+bob,2,2,'gold');poly(belt,at({{19,36},{21,36},{20,40},{18,40}},0,bob),'cream',nil)
 end
 if dir < 2 then
  for yy=40+bob,43 do robe:putPixel(16,yy,0) end
  for xx=15,17 do robe:putPixel(xx,42+bob,0) end
  line(feet,11+a,43+la,13+a,43+la,"hl");line(feet,19+b,43+lb,21+b,43+lb,"hl")
 end
 for i,l in ipairs(layers) do s:newCel(l,s.frames[f],ims[i],Point(0,0)) end
 s.frames[f].duration=walk and .125 or blink and .13 or .38
end
for dir=0,2 do
 local facing=({'front','back','side'})[dir+1]
 for _,range in ipairs({{1,4,'idle'},{5,10,'walk'}}) do local t=s:newTag(s.frames[dir*10+range[1]],s.frames[dir*10+range[2]]);t.name='player-'..facing..'-'..range[3] end
end
s:saveAs(out..'player-cultivator.aseprite')
local sheet=Image(32*30,48,ColorMode.RGB)
for f=1,30 do local im=Image(32,48,ColorMode.RGB);im:drawSprite(s,f,Point(0,0));sheet:drawImage(im,Point((f-1)*32,0)) end
local ss=setup(960,48);ss:newCel(ss.layers[1],ss.frames[1],sheet,Point(0,0));ss:saveAs(out..'player-cultivator-sheet.png')
local preview=setup(144,80);local pi=Image(144,80,ColorMode.RGB);rect(pi,0,0,144,80,'grass')
for d=0,2 do local im=Image(32,48,ColorMode.RGB);im:drawSprite(s,d*10+1,Point(0,0));pi:drawImage(im,Point(12+d*44,12)) end
preview:newCel(preview.layers[1],preview.frames[1],pi,Point(0,0));preview:saveAs(out..'player-preview.png')
local big=Image(576,320,ColorMode.RGB)
for y=0,79 do for x=0,143 do local col=pi:getPixel(x,y);for yy=0,3 do for xx=0,3 do big:putPixel(x*4+xx,y*4+yy,col) end end end end
local bs=Sprite(576,320,ColorMode.RGB);bs:newCel(bs.layers[1],bs.frames[1],big,Point(0,0));bs:saveAs(out..'player-preview4x.png')
-- Two restrained broad grass shapes. Small grouped blades only at one edge, never a tiled scatter.
local grassNames={'grass-meadow-a','grass-meadow-b'}
for n,name in ipairs(grassNames) do
 local g=setup(64,32);g.layers[1].name='01 Quiet meadow';local im=Image(64,32,ColorMode.RGB)
 if n==1 then
  poly(im,{{2,19},{7,16},{9,10},{16,8},{20,10},{27,7},{37,8},{42,11},{50,10},{55,14},{61,15},{62,22},{56,25},{44,24},{35,28},{21,27},{15,29},{6,25}},'shade',nil)
  poly(im,{{4,22},{13,22},{18,24},{23,22},{32,24},{38,22},{45,22},{47,25},{35,28},{21,27},{15,29},{6,25}},'grass',nil)
  poly(im,{{12,14},{11,10},{9,7},{12,8},{14,13},{15,9},{17,6},{16,12},{17,14}},'leaf',nil)
  poly(im,{{18,15},{20,10},{23,8},{22,12},{20,16}},'grass',nil)
 else
  poly(im,{{2,18},{8,12},{12,13},{18,9},{28,7},{37,9},{41,7},{50,9},{53,12},{60,16},{61,23},{52,25},{43,24},{38,28},{25,27},{19,24},{9,25},{5,23}},'shade',nil)
  poly(im,{{36,9},{41,7},{50,9},{53,12},{49,14},{43,13},{41,15},{35,14}},'grass',nil)
  poly(im,{{47,17},{46,11},{44,9},{47,10},{49,16},{50,12},{53,10},{51,16},{50,18}},'leaf',nil)
  poly(im,{{53,18},{56,14},{59,13},{57,17},{54,19}},'grass',nil)
 end
 g:newCel(g.layers[1],g.frames[1],im,Point(0,0));g:saveAs(out..name..'.aseprite');g:saveAs(out..name..'.png');print('EXPORTED '..name..' 64x32')
end
local m=assert(io.open(out..'metadata-main.json','w'));m:write('{"asset_count":3,"palette":"linhthu-v2","player":{"file":"player-cultivator-sheet.png","source":"player-cultivator.aseprite","cell":[32,48],"frames":30,"foot_anchor_px":[16,44],"directions":["front","back","side"],"idle":4,"walk":6,"left":"flip-side"},"grass":["grass-meadow-a","grass-meadow-b"]}\n');m:close()
print('DONE cultivator 32x48, 30 frames / 3 directions, 6 layers, fixed foot anchor [16,44]; two meadow shapes.')
