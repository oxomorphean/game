# Garden V8 — bộ asset cho map logic

Ngày 06/10/2026. Mười thiết kế mới tự vẽ bằng Lua qua Aseprite MCP; PNG đã được nhập bằng Unity plugin và chạy trong scene `Assets/_Project/Content/Scenes/ThanDinhPrototype.unity`. Không mua hoặc tải bộ asset ngoài. Cổng, hai cây anh đào, rùa, hồ và sprite hiệu ứng được giữ từ bộ hiện hành.

| Thiết kế | Canvas / frame | Nguồn editable |
| --- | --- | --- |
| Nhân vật tu tiên | 32×48; 30 frame | `CultivatorAndMeadow/player-cultivator.aseprite` |
| Mảng cỏ A, B | 64×32; mỗi mẫu 1 frame | `CultivatorAndMeadow/grass-meadow-a.aseprite`, `grass-meadow-b.aseprite` |
| Gạch phiến, gạch chia, gạch có cánh hoa | 32×32; mỗi mẫu 1 frame | `Props/paving-slab.aseprite`, `paving-split.aseprite`, `paving-petal.aseprite` |
| Trúc | 48×80; 1 frame | `Props/bamboo.aseprite` |
| Linh thảo | 24×32; 1 frame | `Props/spirit-herb.aseprite` |
| Quặng ngọc | 32×32; 1 frame | `Props/jade-ore.aseprite` |
| Trứng linh thú | 24×32; 1 frame | `Props/spirit-egg.aseprite` |

Nhân vật có ba hướng trước/sau/bên, mỗi hướng idle 4 frame và walk 6 frame; trái lật từ bên phải. Pivot chân `(16,44)` từ góc trên trái. Hai mảng cỏ dùng ba màu, tạo mảng đậm nhẹ và ít lá ở rìa; không rải nét cỏ đều khắp sân. Ba kiểu gạch được phối có trọng số; cánh hoa lát chỉ xuất hiện thưa gần cây. Khóm trúc điểm lấy gỗ được thu nhỏ so với trúc trang trí để tránh che linh thú.

PNG dùng trong game ở `Assets/_Project/Art/GardenV8/`. Unity import Point, PPU 16, không mipmap/nén; sheet nhân vật gồm 30 sprite `cultivator-00` đến `cultivator-29`. Các nguồn `.aseprite` giữ layer; `create-main.lua` và `create-props.lua` tái tạo art. Script hiện có đường dẫn đầu ra tạm, cần đổi hằng đầu ra khi chạy ở nơi khác. Metadata trong từng thư mục ghi thời điểm tạo nguồn; trạng thái đã nhập/chạy hiện hành được xác nhận ở hồ sơ kiểm chứng bên dưới.

## Import và ráp lại

Dừng Play trước. Chạy bằng Unity Pipeline đang mở dự án:

```sh
unity command run_script --project-path /Users/nguyenhoangdacdat/dev/nguthu-unity-demo --caller plugin --skill unity-cli --file AgentScripts/GardenV8Builder.cs --entry GardenV8Builder.Import --format json
unity command run_script --project-path /Users/nguyenhoangdacdat/dev/nguthu-unity-demo --caller plugin --skill unity-cli --file AgentScripts/LogicBuilder.cs --entry LogicBuilder.ApplyArt --format json
```

Sau khi sửa art, xuất PNG về đúng tên trong thư mục game rồi import và ráp lại. Không chạy lại CreateScene chỉ để cập nhật art. [Kiểm chứng V8](../../../Verification/LogicV1/GardenV8/verification.md) chứa ảnh Unity/WebGL, audit import và kiểm tra chuyển động. Bảy prop và nhân vật qua validator không có FAIL/WARN; cỏ không có FAIL nhưng có cảnh báo viền và một pixel lẻ, được giữ ở mức mẫu sơ bộ. Hai vùng dùng cùng sân tạm, trang trí chưa có va chạm riêng.
